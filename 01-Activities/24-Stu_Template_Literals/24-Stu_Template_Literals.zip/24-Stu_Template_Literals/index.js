const music = {
  // code here
};

// write code between the <div> tags to output the data from the music object above
const songSnippet = `
  <div class="song">

  </div>
`;

const element = document.getElementById("music");
element.innerHTML = songSnippet;
